#pragma once

#include "Platform.h"
#include "BaseThread.h"
#include "BaseThread2.h"
#include "BaseThread3.h"
#include "Log.h"
#include "MyMutex.h"
#include "Utility.h"
#include "MyList.h"

#ifdef WIN32
#pragma comment(lib, "Common.lib")
#endif